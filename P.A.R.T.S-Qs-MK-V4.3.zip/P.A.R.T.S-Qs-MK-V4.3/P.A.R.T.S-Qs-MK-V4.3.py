import tkinter as tk
import threading
import queue
import datetime
import os
import sys
import time
import numpy as np
import sounddevice as sd
import pyttsx3
import webbrowser
from llama_cpp import Llama
import sherpa_onnx
import subprocess
import winsound

# ================= CONFIGURATION =================
SHERPA_MODEL_PATH = r"C:\Users\User\Downloads\sherpa-onnx-paraformer-en-2024-03-09"
LLM_MODEL_PATH    = r"C:\Users\User\Downloads\SmolLM3-3B.Q4_K_M.gguf"

# ================= SOUND EFFECTS =================
# Replace these paths with the actual .wav files from your Downloads folder
SOUND_PROGRAM_START = r"C:\Users\User\Downloads\startup.wav"
SOUND_COMMAND       = r"C:\Users\User\Downloads\command.wav"

# ================= SHERPA-ONNX INIT =================
tokens_file = f"{SHERPA_MODEL_PATH}/tokens.txt"   # ensure correct name

recognizer = sherpa_onnx.OfflineRecognizer.from_paraformer(
    paraformer=f"{SHERPA_MODEL_PATH}/model.onnx",
    tokens=tokens_file,
    sample_rate=16000,
    decoding_method="greedy_search",
)

# ================= LLM INIT =================
llm = Llama(
    model_path=LLM_MODEL_PATH,
    n_gpu_layers=-1,
    n_ctx=4096,
    n_threads=4,
    verbose=True,
)

# ================= THREADING & STATE =================
llm_lock = threading.Lock()
processing = False
recording_allowed = True
audio_queue = queue.Queue()
volume_queue = queue.Queue()               # for live bar

# ================= SPEECH QUEUE (TTS) =================
speech_queue = queue.Queue()
tts_done_queue = queue.Queue()

def speech_worker():
    temp_engine = pyttsx3.init()
    temp_engine.setProperty('rate', 175)
    hazel_id = None
    for voice in temp_engine.getProperty('voices'):
        if 'hazel' in voice.id.lower():
            hazel_id = voice.id
            break
    del temp_engine

    while True:
        text = speech_queue.get()
        if text is None:
            break
        engine = pyttsx3.init()
        engine.setProperty('rate', 175)
        if hazel_id:
            engine.setProperty('voice', hazel_id)
        engine.say(text)
        engine.runAndWait()
        del engine
        tts_done_queue.put(True)

threading.Thread(target=speech_worker, daemon=True).start()

# ================= GUI HELPERS =================
def append_chat(text):
    chat.after(0, lambda: chat.configure(state="normal"))
    chat.after(0, lambda: chat.insert(tk.END, text + "\n"))
    chat.after(0, lambda: chat.see(tk.END))
    chat.after(0, lambda: chat.configure(state="disabled"))

def speak(text):
    append_chat("Assistant: " + text)
    speech_queue.put(text)

def speak_and_wait(text):
    speak(text)
    def _wait():
        tts_done_queue.get()
        global processing, recording_allowed
        processing = False
        recording_allowed = True
    threading.Thread(target=_wait, daemon=True).start()
    
def play_sound(file_path):
    """Play a .wav file asynchronously if it exists."""
    if os.path.exists(file_path):
        winsound.PlaySound(file_path, winsound.SND_ASYNC)

# ================= AI ENGINE =================
def ask_ai(prompt):
    prompt_formatted = f"""User: {prompt}
Assistant:"""
    with llm_lock:
        output = llm(prompt_formatted, max_tokens=2000, stop=["User:", "\n"], echo=False)
    return output['choices'][0]['text'].strip()

# ================= COMMANDS =================
app_commands = {
    "youtube": "https://youtube.com",
    "github": "https://github.com",
    "browser": "",               # empty = just open Chrome
    "spotify": "https://open.spotify.com",
}

# ================= BRAIN =================
def run(command):
    global processing, recording_allowed
    recording_allowed = False
    processing = True

    command = command.lower().strip()
    append_chat("You: " + command)
    play_sound(SOUND_COMMAND)
    print(f"[DEBUG] Command received: {command}")

    greetings = ["hello", "hi", "hey", "come in", "good morning", "good afternoon", "good evening", "come forth"]
    matched_greeting = False
    for greet in greetings:
        if greet in command and "parts" in command:
            speak_and_wait("Systems check. All assets affirmative. PARTS online. Ready and standing by. Awaiting command.")
            matched_greeting = True
            break
    if matched_greeting:
        return

    if "what is your name" in command or "who are you" in command:
        speak_and_wait("PARTS, Proxy Artificial Response Terminal System. An Artificial Intelligence derived from the Q4KM-SmolLM3 Language model. I am able to carry out various tasks locally, but my main purpose is to assist with any and all of my creator's research.")
    elif "time" in command:
        now = datetime.datetime.now().strftime("%I:%M %p")
        speak_and_wait(f"The time is {now}")
    elif "date" in command:
        today = datetime.datetime.now()
        speak_and_wait(f"Today is {today.strftime('%A, %d %B %Y')}")
    elif "history" in command:
        chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
        if os.path.exists(chrome_path):
            speak_and_wait("Initiating browser record launch.")
            subprocess.Popen([chrome_path, "--new-tab", "chrome://history/"])
        else:
            speak_and_wait("Chrome not found at the default location.")
    elif "initiate search file" in command:
        trigger = "initiate search file"
        idx = command.find(trigger)
        if idx != -1:
            filename = command[idx + len(trigger):].strip().lstrip(",").strip()
            print(f"[DEBUG] Searching for file: '{filename}'")
            if filename:
                search_uri = f"search-ms:query={filename}"
                webbrowser.open(search_uri)
                speak_and_wait(f"Searching for {filename}")
            else:
                speak_and_wait("Please specify a file name after 'initiate search file'.")
        else:
            speak_and_wait("I didn't catch the file name.")
    elif "initiate launch" in command:
        trigger = "initiate launch"
        idx = command.find(trigger)
        if idx != -1:
            app = command[idx + len(trigger):].strip().lstrip(",").strip()
            print(f"[DEBUG] App extracted: '{app}'")
            chrome_path = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
            if app in app_commands:
                if os.path.exists(chrome_path):
                    url = app_commands[app].strip()
                    if url:
                        subprocess.Popen([chrome_path, url])
                    else:
                        subprocess.Popen([chrome_path])   # just open Chrome
                    speak_and_wait(f"Opening {app}")
                else:
                    speak_and_wait("Error404 not found.")
            elif app == "powershell":
                os.system("start powershell")
                speak_and_wait("Opening PowerShell")
            else:
                speak_and_wait("I don't know that application.")
        else:
            speak_and_wait("I didn't catch the application name.")
    elif "cut program" in command or "format current engine" in command or "bye" in command:
        speak("Goodbye!")
        window.after(1000, window.destroy)
        return
    else:
        try:
            response = ask_ai(command)
            speak_and_wait(response)
        except Exception as e:
            speak_and_wait("Sorry, I encountered an error while thinking.")
            print(f"LLM error: {e}")

# ================= VOICE LISTENER (with FIXED flushing) =================
def listen():
    def audio_callback(indata, frames, time_info, status):
        # Always compute RMS for visualizer
        samples = indata[:, 0].astype(np.float32) / 32768.0
        rms = np.sqrt(np.mean(samples**2))
        if not hasattr(audio_callback, "counter"):
            audio_callback.counter = 0
        audio_callback.counter += 1
        if audio_callback.counter % 10 == 0:
            volume_queue.put(rms)

        if not recording_allowed:
            return
        audio_queue.put(indata.copy())

    SILENCE_THRESHOLD = 0.01
    PAUSE_DURATION = 1.0

    accumulated_samples = []
    last_speech_time = 0.0

    with sd.InputStream(samplerate=16000, channels=1, dtype='int16',
                        callback=audio_callback):
        while True:
            indata = audio_queue.get()

            # ---- FIX: Flush everything when the gate is closed ----
            if not recording_allowed:
                accumulated_samples = []
                last_speech_time = 0.0
                while not audio_queue.empty():
                    try:
                        audio_queue.get_nowait()
                    except queue.Empty:
                        break
                continue

            samples = indata[:, 0].astype(np.float32) / 32768.0
            rms = np.sqrt(np.mean(samples**2))
            now = time.time()

            if rms > SILENCE_THRESHOLD:
                accumulated_samples.append(samples)
                last_speech_time = now
            else:
                if accumulated_samples and (now - last_speech_time) > PAUSE_DURATION:
                    # Safety: ensure we have enough audio
                    if len(accumulated_samples) == 0:
                        continue
                    full_audio = np.concatenate(accumulated_samples)
                    if len(full_audio) < 1600:   # < 0.1 sec
                        accumulated_samples = []
                        continue

                    stream = recognizer.create_stream()
                    stream.accept_waveform(sample_rate=16000, waveform=full_audio)
                    recognizer.decode_stream(stream)
                    result_text = stream.result.text.strip()
                    accumulated_samples = []

                    if result_text and not processing:
                        threading.Thread(target=run, args=(result_text,), daemon=True).start()

# ================= GUI INTERACTION =================
def send():
    global processing
    msg = entry.get().strip()
    if msg == "" or processing:
        return
    processing = True
    entry.delete(0, tk.END)
    threading.Thread(target=run, args=(msg,), daemon=True).start()

# ================= GUI SETUP (with fixed text box visibility) =================
window = tk.Tk()
window.title("PARTS - SmolLM3 Assistant")
window.geometry("700x1080")
window.configure(bg="black")

# Main container: left bar + chat
main_frame = tk.Frame(window, bg="black")
main_frame.pack(fill="both", expand=True)

# --- Audio Visualizer (left side) ---
viz_width = 30
viz_height = 800
viz_canvas = tk.Canvas(main_frame, width=viz_width, height=viz_height, bg="black", highlightthickness=0)
viz_canvas.pack(side="left", fill="y", padx=(5, 0), pady=10)

bar_width = 20
bar_x = (viz_width - bar_width) // 2
bar = viz_canvas.create_rectangle(bar_x, viz_height, bar_x + bar_width, viz_height, fill="orange", outline="")

# --- Chat area (right side) – now READ-ONLY ---
chat = tk.Text(main_frame, bg="black", fg="orange", font=("Courier Prime", 11), wrap=tk.WORD, state="disabled")
chat.pack(side="left", expand=True, fill="both", padx=(5, 10), pady=10)

# --- Entry and Send button (bottom of window) ---
entry_frame = tk.Frame(window, bg="black")
entry_frame.pack(fill="x", padx=10, pady=(0,5))

entry = tk.Entry(entry_frame, bg="gray20", fg="orange", font=("Consolas", 12))
entry.pack(side="left", expand=True, fill="x")

button = tk.Button(entry_frame, text="SEND", command=send, bg="brown", fg="yellow", font=("Courier Prime", 12, "bold"))
button.pack(side="right", padx=(5,0))
entry.bind("<Return>", lambda e: send())

# Give the entry field focus so you can type immediately
entry.focus_set()

# --- Visualizer updater (smooth) ---
def update_visualizer():
    if not hasattr(update_visualizer, "history"):
        update_visualizer.history = [0.0] * 5
    while not volume_queue.empty():
        val = volume_queue.get_nowait()
        update_visualizer.history.pop(0)
        update_visualizer.history.append(val)
    avg_rms = sum(update_visualizer.history) / len(update_visualizer.history)
    max_height = viz_height * 0.9
    bar_height = min(max_height, avg_rms * (max_height / 0.2))
    y1 = viz_height - bar_height
    y2 = viz_height
    viz_canvas.coords(bar, bar_x, y1, bar_x + bar_width, y2)
    window.after(30, update_visualizer)

update_visualizer()

# ================= START =================
threading.Thread(target=listen, daemon=True).start()
# Use a helper to append the first message (because chat is disabled)
chat.configure(state="normal")
chat.insert(tk.END, "Assistant: PARTS online. Type or speak a command.\n")
chat.see(tk.END)
chat.configure(state="disabled")
# Play startup sound
play_sound(SOUND_PROGRAM_START)
window.mainloop()